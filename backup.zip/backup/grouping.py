import requests
from bs4 import BeautifulSoup
import re
import json
import os

# COMMUNITY
KABUPATEN_URL = "https://goodkind.id/api/communities?level=Kabupaten&size=500"
KOTA_URL = "https://goodkind.id/api/communities?level=Kota&size=500"
PROVINSI_URL = "https://goodkind.id/api/communities?level=Provinsi&size=500"

KABUPATEN = json.loads(requests.get(KABUPATEN_URL).text)
KOTA = json.loads(requests.get(KOTA_URL).text)
PROVINSI = json.loads(requests.get(PROVINSI_URL).text)

# WEB DATA DAERAH PEMILIHAN DPR RI FROM kpu.go.id
url = "https://id.wikipedia.org/wiki/Daftar_pemilihan_umum_kepala_daerah_di_Indonesia_2024"
page = requests.get(url)
soup = BeautifulSoup(page.content, "html5lib")
links = soup.find_all("a", string=re.compile("^Pemilihan"))

linkWithIndex = {}
for link in links:
    linkWithIndex[link.text] = link.get("href")

# EXISTING DATA: data-2.json
data = []
if os.path.exists("data-2.json"):
    with open("data-2.json", "r") as f:
        data = json.load(f)

# FUNCTIONS
# CLEAN WIKI URL
def getWikiUrl(wiki):
    try:
        if ("action=edit" in wiki):
            return ""

        return "https://id.wikipedia.org" + wiki
    except:
        return ""

# GET COMMUNITY PATH
def getCommunityPath(level, keyword):
    keyword = (level + " " + keyword).lower().replace(" ", "")

    # if keyword contains sumatera replace with Sumatra 
    keyword = keyword.replace("sumatera", "sumatra")
    keyword = keyword.replace("kotapadangsidempuan", "kotapadangsidimpuan")
    keyword = keyword.replace("kotatangjungbalai", "kotatanjungbalai")

    lists = []

    if (level == "KABUPATEN"):
        lists = KABUPATEN.get("data", [])

    elif (level == "KOTA"):
        lists = KOTA.get("data", [])

    elif (level == "PROVINSI"):
        lists = PROVINSI.get("data", [])

    for item in lists:
        if (keyword in item.get("name", "").lower().replace(" ", "")):
            return item.get("path")

    print("NOT FOUND: " + keyword)
    return ""

# DATA WITH SOURCE
dataWithSource = []
for item in data:
    item.update({
        "source": getWikiUrl(linkWithIndex[item['title']]),
        "path": getCommunityPath(item['level'], item['region'])
    })
    
    dataWithSource.append(item)


# LIST ITEMS WITH ZERO CANDIDATES BUT HAS WIKI URL
zeroCandidates = []
for item in dataWithSource:
    if (item['path'] !="" and item['source'] != "" and item['candidates'] == []):
        zeroCandidates.append(item)

# SAVE DATA: save zero candidates to zero_candidate.json
with open("zero_candidate.json", "w") as f:
    f.write(json.dumps(zeroCandidates, indent=4))
    f.close()

# SAVE DATA: each data item file name is path.json
# check if folder communities exist, if not create the folder
if not os.path.exists("communities"):
    os.mkdir("communities")

for item in dataWithSource:
    if (item['path'] == ""):
        continue

    with open("communities/" + item['path'] + ".json", "w") as f:
        f.write(json.dumps(item, indent=4))
        f.close()

print("DONE")