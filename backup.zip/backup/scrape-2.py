import requests
from bs4 import BeautifulSoup
import re
import json
import os

# WEB DATA DAERAH PEMILIHAN DPR RI FROM kpu.go.id
url = "https://id.wikipedia.org/wiki/Daftar_pemilihan_umum_kepala_daerah_di_Indonesia_2024"
page = requests.get(url)
soup = BeautifulSoup(page.content, "html5lib")
links = soup.find_all("a", string=re.compile("^Pemilihan"))

# GENERATE WIKI URL
def get_wiki_url(link):
    if not link or not link.get("href"):
        return None

    if "https://id.wikipedia.org" in link.get("href"):
        return link.get("href")

    return "https://id.wikipedia.org" + link.get("href")

def cleanup_citation(text):
    if not text:
        return None
        
    return re.sub(r"\[.*?\]", "", text).strip()

def get_region(text):
    # remove Pemilihan umum Gubernur, Pemilihan umum Bupati, Pemilihan umum Wali Kota, 2024
    # eg. "Pemilihan umum Gubernur Sumatera Utara 2024" = "Sumatera Utara"

    region = text.replace("Pemilihan umum ", "")
    region = region.replace("Gubernur", "")
    region = region.replace("Bupati", "")
    region = region.replace("Wali Kota", "")
    region = region.replace("2024", "")
    region = region.strip()

    return region

def get_title(level):
    switcher = {
        "PROVINSI": "Calon Gubernur",
        "KABUPATEN": "Calon Bupati",
        "KOTA": "Calon Wali Kota"
    }

    return switcher.get(level, "")

# SCRAPE DETAIL CANDIDATE
def get_detail_candidate(link, level, name=None):
    if link:
        if not get_wiki_url(link):
            return None

        page = requests.get(get_wiki_url(link))
        soup = BeautifulSoup(page.content, "html5lib")

        if not soup:
            return None

        # GET NAME
        # name = soup.find("span", class_="mw-page-title-main").text # NOTE: NOT CONTAINS NAME'S TITLE
        name = link.text

        try:
            # GET FIRST DESCRIPTION OF CANDIDATE
            description = soup.find("div", class_="mw-parser-output").find("p")
            if description:
                description = description.text
            else:
                description = ""
        except:
            description = ""

        # PROFILE PICTURE
        # profile_pic = soup.find("img", src=re.compile("thumb")).get("src")
        profile_pic = soup.find("a", href=re.compile('/wiki/Berkas:')).find("img").get("src")
        if profile_pic and not profile_pic.startswith("https"):
            profile_pic = "https:" + profile_pic
    else:
        name = name
        description = ""
        profile_pic = ""

    return {
        "name": name,
        "title": get_title(level),
        "description": cleanup_citation(description),
        "profilePic": profile_pic,
        "wiki": get_wiki_url(link),
        "communityID": "",
    }

# SCRAPE DETAIL PEMILIHAN
def get_detail_pemilihan(link):
    if not get_wiki_url(link):
        return None

    page = requests.get(get_wiki_url(link))
    soup = BeautifulSoup(page.content, "html5lib")

    # GET TITLE
    title = link.text

    # GET REGION
    region = get_region(title)

    # GET LEVEL
    level = "PROVINSI" if "Gubernur" in title else "KABUPATEN" if "Bupati" in title else "KOTA" if "Wali Kota" in title else "-"

    # GET `POTENSIAL` SECTION AND SELECT THE NEXT UL SIBLING
    try:
        heading = soup.find("span", id="Potensial")
        if heading:
            potential_lists = heading.parent.find_next_sibling("ul")
        else:
            potential_lists = soup.find("h3").find_next_sibling("ul")

        # GET THE FIRST URL IN THE LIST
        candidate_details = []
        for item in potential_lists.find_all("li"):
            tag_a = item.find("a")
            tag_text = item.find("b") or item.text.split(", ")[0]

            detail = None

            if tag_a:
                detail = get_detail_candidate(link=tag_a, level=level)
            elif tag_text:
                detail = get_detail_candidate(link=None, level=level, name=tag_text.text)
            else:
                continue
            
            if detail:
                candidate_details.append(detail)
    except Exception as e:
        print(f"ERROR: {e}")
        candidate_details = []

    return {
        "title": title,
        "region": region,
        "level": level,
        "candidates": candidate_details
    }

data = []
temp_links = []

def store_data(batch):
    # CREATE FOLDER DATA IF NOT EXIST
    if not os.path.exists("output-2"):
        os.makedirs("output-2")

    # STORE RESULT TO data.json
    with open(f"output-2/data-" + str(batch) + ".json", "w") as f:
        f.write(json.dumps(data, indent=4))

def save_links():
    # CREATE FOLDER DATA IF NOT EXIST
    if not os.path.exists("output-2"):
        os.makedirs("output-2")

    links = ""
    for link in temp_links:
        links += link.text + "\n"

    with open("output-2/links.txt", "a") as f:
        f.write(links)

def handle_store_data(link):
    index = links.index(link)

    if index % 10 == 0 or index == len(links) - 1:
        store_data(index // 10)
        save_links()
        
        data.clear()
        temp_links.clear()

        print("Data stored")

    print(f"{index}/{len(links)} - {link.text}")

def is_scraped(link):
    if not os.path.exists("output-2") or not os.path.exists("output-2/links.txt"):
        return False

    with open("output-2/links.txt", "r") as f:
        if link.text in f.read():
            return True

    return False


for link in links:
    if is_scraped(link):
        continue

    pemilihan = get_detail_pemilihan(link)
    data.append(pemilihan)
    temp_links.append(link)

    handle_store_data(link)


print("Done!")