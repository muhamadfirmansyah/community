import requests
from bs4 import BeautifulSoup
import re
import json
import os

data = []
if os.path.exists("zero_candidate.json"):
    with open("zero_candidate.json", "r") as f:
        data = json.load(f)

# GET CANDIDATE
def get_candidates(source):
    page = requests.get(source)
    soup = BeautifulSoup(page.content, "html5lib")

    try:
        parent = soup.find("span", id="Potensial").parent.find_next_sibling("ul")
        ul = [x for x in parent.find_all("li")]

        candidates = []
        for li in ul:
            candidate = li.find("a")

            if (not candidate):
                try:
                    candidate = li.text.split(", ")[0]
                except:
                    continue

            candidates.append(candidate)

        print(candidates)
    except:
        return


for item in data:
    wiki = item['source']
    
    get_candidates(wiki)
    break

