import os
import json
import requests
from bs4 import BeautifulSoup
import re

KABUPATEN_URL = "https://goodkind.id/api/communities?level=Kabupaten&size=500"
KOTA_URL = "https://goodkind.id/api/communities?level=Kota&size=500"
PROVINSI_URL = "https://goodkind.id/api/communities?level=Provinsi&size=500"

KABUPATEN = json.loads(requests.get(KABUPATEN_URL).text)
KOTA = json.loads(requests.get(KOTA_URL).text)
PROVINSI = json.loads(requests.get(PROVINSI_URL).text)

def cleanup_image(url):
    blocked_words = ["arrow_left_pictogram", "icon", "hsutvald.svg", "logo", "semi-protection-shackle", "ambox_important", "question_book-new.svg", "Disambig_gray", "arms_of_", "Disambig_gray", "Seal_of", "orange-source", "Edit-clear", "Flag_of"]

    if any(word.lower() in url.lower() for word in blocked_words):
        return ""
    
    return url
    

output_folder = "output-2"
result_file = "data-2.json"
files = os.listdir(output_folder)

data_files = [f for f in files if f.startswith("data-")]

data = []

# LOAD DATA TO `data`
for file in data_files:
    with open(os.path.join(output_folder, file), "r") as f:
        data.extend(json.load(f))

# GET COMMUNITY ID
def get_community_id(level, keyword):
    # add Kota, Kabupten, Provinsi to keyword
    prefixs = {
        "KABUPATEN": "Kabupaten",
        "KOTA": "Kota",
        "PROVINSI": "Provinsi"
    }

    if (level in prefixs):
        keyword = prefixs[level] + " " + keyword

    keyword = keyword.lower().replace(" ", "")

    # if keyword contains sumatera replace with Sumatra 
    keyword = keyword.replace("sumatera", "sumatra")
    keyword = keyword.replace("kotatangjungbalai", "kotatanjungbalai")

    lists = []

    if (level == "KABUPATEN"):
        lists = KABUPATEN.get("data", [])

    elif (level == "KOTA"):
        lists = KOTA.get("data", [])

    elif (level == "PROVINSI"):
        lists = PROVINSI.get("data", [])

    for item in lists:
        if (keyword in item.get("name", "").lower().replace(" ", "")):
            return item.get("id")

    print(keyword)
    return ""


# CLEAN WIKI URL
def get_wiki_url(wiki):
    try:
        if ("action=edit" in wiki):
            return None

        return {
            "name": "Wikipedia",
            "url": wiki
        }
    except:
        return None

def get_profile_pic(wiki):
    if (not wiki):
        return ""

    try:
        page = requests.get(wiki)
        soup = BeautifulSoup(page.content, "html5lib")

        # profile_pic = soup.find("a", href=re.compile("/wiki/Berkas")).find("img", src=re.compile("/thumb")).get("src")
        profile_pic = soup.find("a", href=re.compile('/wiki/Berkas:')).find("img").get("src")

        if profile_pic and not profile_pic.startswith("https"):
            profile_pic = "https:" + profile_pic

        return profile_pic
    except Exception as e:
        return ""
    

# FIXING SOME DATA
for item in data:
    candidates = item.get("candidates", [])
    
    if (len(candidates)):
        level = item.get("level")
        region = item.get("region")

        communityID = get_community_id(level, region)

        for candidate in candidates:
            try:
                profile_pic = cleanup_image(candidate.get("profilePic", ""))

                if (profile_pic == ""):
                    profile_pic = get_profile_pic(candidate.get("wiki"))

                candidate.update({
                    "profilePic": cleanup_image(profile_pic),
                    "communityID": communityID,
                    "sites": get_wiki_url(candidate.get("wiki", ""))
                })

                candidate.pop("wiki")

            except Exception as e:
                print(e)
                pass


        # remove candidate if the name has `[]`
        candidates = [c for c in candidates if not ("[" in c.get("name", "") or "]" in c.get("name", ""))]
        item.update({
            "candidates": candidates
        })

with open(result_file, "w") as f:
    f.write(json.dumps(data, indent=4))

print(f"Data saved to {result_file}")